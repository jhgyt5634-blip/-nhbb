package com.example.addon;

import com.example.addon.modules.*;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;

// Keep the rest of the template's file (getRepo() etc.) if it has it - just make sure these parts match.
public class AddonTemplate extends MeteorAddon {
    public static final Category CATEGORY = new Category("Custom");

    @Override
    public void onInitialize() {
        Modules.get().add(new CustomFlight());
        Modules.get().add(new CustomSpeed());
        Modules.get().add(new SusChunks());
        Modules.get().add(new BaseFinder());
        Modules.get().add(new SpectatorCam());
        Modules.get().add(new BindSettings());
    }

    @Override
    public void onRegisterCategories() {
        Modules.registerCategory(CATEGORY);
    }

    @Override
    public String getPackage() {
        return "com.example.addon";
    }
}
