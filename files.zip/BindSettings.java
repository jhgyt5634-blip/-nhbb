package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.orbit.EventHandler;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Central place to set the key for every custom module. Enable this module once and leave it on. */
public class BindSettings extends Module {
    public enum Mode { Toggle, Hold }

    private final SettingGroup sg = settings.getDefaultGroup();

    private final Setting<Mode> mode = sg.add(new EnumSetting.Builder<Mode>()
        .name("mode").description("Toggle: press once to turn on/off. Hold: active only while the key is held.")
        .defaultValue(Mode.Toggle).build());

    private final Setting<Boolean> ignoreInScreens = sg.add(new BoolSetting.Builder()
        .name("ignore-in-screens").description("Don't react to binds while chat, inventory or menus are open.")
        .defaultValue(true).build());

    private final Setting<Keybind> flight = bind("flight", GLFW.GLFW_KEY_G);
    private final Setting<Keybind> speed = bind("speed", GLFW.GLFW_KEY_H);
    private final Setting<Keybind> susChunks = bind("sus-chunks", GLFW.GLFW_KEY_J);
    private final Setting<Keybind> baseFinder = bind("base-finder", GLFW.GLFW_KEY_K);
    private final Setting<Keybind> spectatorCam = bind("spectator-cam", GLFW.GLFW_KEY_L);

    private record Entry(Class<? extends Module> cls, Setting<Keybind> bind) {}

    private final List<Entry> entries = List.of(
        new Entry(CustomFlight.class, flight),
        new Entry(CustomSpeed.class, speed),
        new Entry(SusChunks.class, susChunks),
        new Entry(BaseFinder.class, baseFinder),
        new Entry(SpectatorCam.class, spectatorCam)
    );

    private final Map<Class<? extends Module>, Boolean> wasDown = new HashMap<>();

    public BindSettings() {
        super(AddonTemplate.CATEGORY, "bind-settings", "Set the key for each custom module in one place. Keep this module enabled.");
    }

    private Setting<Keybind> bind(String name, int defaultKey) {
        return sg.add(new KeybindSetting.Builder()
            .name(name + "-bind").description("Key for " + name + ". Click, then press a key (Escape/none to clear).")
            .defaultValue(Keybind.fromKey(defaultKey)).build());
    }

    @Override
    public void onDeactivate() {
        wasDown.clear();
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null) return;
        boolean blocked = ignoreInScreens.get() && mc.screen != null;

        for (Entry e : entries) {
            Module m = Modules.get().get(e.cls());
            if (m == null) continue;

            Keybind kb = e.bind().get();
            boolean pressed = !blocked && kb.isSet() && kb.isPressed();
            boolean was = wasDown.getOrDefault(e.cls(), false);

            if (mode.get() == Mode.Toggle) {
                if (pressed && !was) m.toggle();
            } else {
                if (pressed && !was && !m.isActive()) m.toggle();
                if (!pressed && was && m.isActive()) m.toggle();
            }
            wasDown.put(e.cls(), pressed);
        }
    }
}
